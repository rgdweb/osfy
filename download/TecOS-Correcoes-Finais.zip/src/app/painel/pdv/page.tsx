'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import {
  ShoppingCart,
  Search,
  Plus,
  Minus,
  Trash2,
  CreditCard,
  Banknote,
  QrCode,
  Package,
  X,
  Check,
  Barcode,
  User,
  Printer,
  FileText,
  Share2,
  AlertTriangle,
  Clock,
  Receipt,
  XCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'

interface Produto {
  id: string
  nome: string
  codigoBarras: string | null
  precoVenda: number
  estoque: number
  categoria?: { nome: string } | null
}

interface ItemCarrinho {
  id: string
  produtoId?: string
  descricao: string
  quantidade: number
  precoUnitario: number
  total: number
  tipo: 'produto' | 'avulso'
}

interface Caixa {
  id: string
  status: string
  saldoInicial: number
}

interface VendaRealizada {
  id: string
  numeroVenda: number
  subtotal: number
  desconto: number
  total: number
  formaPagamento: string
  valorPago: number | null
  troco: number | null
  clienteNome?: string
  itens: Array<{
    descricao: string
    quantidade: number
    precoUnitario: number
    total: number
  }>
}

interface LojaInfo {
  nome: string
  endereco: string
  telefone: string
}

interface Cliente {
  id: string
  nome: string
}

const formasPagamento = [
  { value: 'dinheiro', label: 'Dinheiro', icon: Banknote },
  { value: 'pix', label: 'PIX', icon: QrCode },
  { value: 'cartao_credito', label: 'Cartão Crédito', icon: CreditCard },
  { value: 'cartao_debito', label: 'Cartão Débito', icon: CreditCard },
]

export default function FrenteDeCaixa() {
  const router = useRouter()
  const barcodeInputRef = useRef<HTMLInputElement>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)

  // Estados do PDV
  const [caixa, setCaixa] = useState<Caixa | null>(null)
  const [loja, setLoja] = useState<LojaInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [barcodeBuffer, setBarcodeBuffer] = useState('')
  const [showBarcodeInput, setShowBarcodeInput] = useState(false)

  // Estados do carrinho
  const [itens, setItens] = useState<ItemCarrinho[]>([])
  const [desconto, setDesconto] = useState(0)

  // Estados de busca
  const [busca, setBusca] = useState('')
  const [produtosBusca, setProdutosBusca] = useState<Produto[]>([])
  const [showBuscaProdutos, setShowBuscaProdutos] = useState(false)

  // Estados de cliente
  const [clienteBusca, setClienteBusca] = useState('')
  const [clientesEncontrados, setClientesEncontrados] = useState<Cliente[]>([])
  const [clienteSelecionado, setClienteSelecionado] = useState<Cliente | null>(null)

  // Estados de pagamento
  const [showPagamento, setShowPagamento] = useState(false)
  const [formaPagamento, setFormaPagamento] = useState('')
  const [valorPago, setValorPago] = useState('')

  // Estados de venda avulsa
  const [showVendaAvulsa, setShowVendaAvulsa] = useState(false)
  const [avulsaDescricao, setAvulsaDescricao] = useState('')
  const [avulsaValor, setAvulsaValor] = useState('')

  // Estado da venda concluída
  const [vendaConcluida, setVendaConcluida] = useState<VendaRealizada | null>(null)
  const [showVendaConcluida, setShowVendaConcluida] = useState(false)

  // Estados de fechar caixa
  const [showFecharCaixa, setShowFecharCaixa] = useState(false)
  const [saldoFinalInput, setSaldoFinalInput] = useState('')
  const [observacaoFechamento, setObservacaoFechamento] = useState('')
  const [fechandoCaixa, setFechandoCaixa] = useState(false)

  // Estado para caixa existente
  const [showCaixaExistente, setShowCaixaExistente] = useState(false)
  const [novoSaldoInicial, setNovoSaldoInicial] = useState(0)

  // Calcular totais
  const subtotal = itens.reduce((acc, item) => acc + item.total, 0)
  const total = subtotal - desconto
  const troco = valorPago && parseFloat(valorPago) > total ? parseFloat(valorPago) - total : 0

  // Carregar caixa e loja
  useEffect(() => {
    loadCaixa()
    loadLoja()
  }, [])

  // Alerta ao sair da página com itens no carrinho
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (itens.length > 0) {
        e.preventDefault()
        e.returnValue = 'Você tem itens no carrinho. Sair da página irá perder a venda. Deseja continuar?'
        return e.returnValue
      }
    }

    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => window.removeEventListener('beforeunload', handleBeforeUnload)
  }, [itens.length])

  // Alerta ao tentar navegar dentro do app
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const link = target.closest('a')
      
      if (link && itens.length > 0) {
        const href = link.getAttribute('href')
        if (href && !href.includes('/painel/pdv')) {
          e.preventDefault()
          if (confirm('Você tem itens no carrinho. Sair da página irá perder a venda. Deseja continuar?')) {
            setItens([])
            router.push(href)
          }
        }
      }
    }

    document.addEventListener('click', handleClick)
    return () => document.removeEventListener('click', handleClick)
  }, [itens.length, router])

  // Listener para código de barras via keyboard
  useEffect(() => {
    let timeoutId: NodeJS.Timeout

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return
      }

      // F2 abre busca de produtos
      if (e.key === 'F2') {
        e.preventDefault()
        setShowBuscaProdutos(true)
        setTimeout(() => searchInputRef.current?.focus(), 100)
        return
      }

      // F3 abre venda avulsa
      if (e.key === 'F3') {
        e.preventDefault()
        setShowVendaAvulsa(true)
        return
      }

      // F4 abre pagamento
      if (e.key === 'F4') {
        e.preventDefault()
        if (itens.length > 0) {
          setShowPagamento(true)
        }
        return
      }

      // Enter processa o buffer como código de barras
      if (e.key === 'Enter' && barcodeBuffer.length > 3) {
        e.preventDefault()
        buscarProdutoPorCodigo(barcodeBuffer)
        setBarcodeBuffer('')
        return
      }

      // Acumular caracteres para código de barras
      if (e.key.length === 1) {
        setBarcodeBuffer(prev => {
          const newBuffer = prev + e.key
          clearTimeout(timeoutId)
          timeoutId = setTimeout(() => setBarcodeBuffer(''), 50)
          return newBuffer
        })
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      clearTimeout(timeoutId)
    }
  }, [barcodeBuffer, itens.length])

  const loadCaixa = async () => {
    try {
      const res = await fetch('/api/painel/pdv/caixa')
      const data = await res.json()
      if (data.success) {
        setCaixa(data.caixaAberto || null)
      }
    } catch {
      toast.error('Erro ao carregar caixa')
    } finally {
      setLoading(false)
    }
  }

  const loadLoja = async () => {
    try {
      const res = await fetch('/api/painel/configuracoes')
      const data = await res.json()
      if (data.success && data.loja) {
        setLoja({
          nome: data.loja.nome || 'TecOS PDV',
          endereco: data.loja.endereco || '',
          telefone: data.loja.telefone || ''
        })
      }
    } catch {
      // Silencioso
    }
  }

  const abrirCaixa = async (saldoInicial: number) => {
    try {
      const checkRes = await fetch('/api/painel/pdv/caixa')
      const checkData = await checkRes.json()
      
      if (checkData.success && checkData.caixaAberto) {
        setNovoSaldoInicial(saldoInicial)
        setShowCaixaExistente(true)
        return
      }

      const res = await fetch('/api/painel/pdv/caixa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saldoInicial })
      })
      const data = await res.json()
      if (data.success) {
        setCaixa(data.caixa)
        toast.success('Caixa aberto com sucesso!')
      } else {
        toast.error(data.error || 'Erro ao abrir caixa')
      }
    } catch {
      toast.error('Erro ao abrir caixa')
    }
  }

  const fecharEAbrirNovoCaixa = async () => {
    if (!caixa) return
    
    setFechandoCaixa(true)
    try {
      const fecharRes = await fetch('/api/painel/pdv/caixa/fechar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caixaId: caixa.id,
          saldoFinal: caixa.saldoInicial,
          observacao: 'Fechado automaticamente para abrir novo caixa'
        })
      })
      
      if (!fecharRes.ok) {
        toast.error('Erro ao fechar caixa anterior')
        return
      }

      const abrirRes = await fetch('/api/painel/pdv/caixa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saldoInicial: novoSaldoInicial })
      })
      const abrirData = await abrirRes.json()
      
      if (abrirData.success) {
        setCaixa(abrirData.caixa)
        setShowCaixaExistente(false)
        toast.success('Caixa anterior fechado e novo caixa aberto!')
      } else {
        toast.error(abrirData.error || 'Erro ao abrir novo caixa')
      }
    } catch {
      toast.error('Erro ao processar operação')
    } finally {
      setFechandoCaixa(false)
    }
  }

  const buscarProdutoPorCodigo = async (codigo: string) => {
    try {
      const res = await fetch(`/api/painel/pdv/produtos?codigo_barras=${encodeURIComponent(codigo)}`)
      const data = await res.json()
      
      if (data.success && data.produto) {
        adicionarItem(data.produto)
      } else {
        toast.error('Produto não encontrado')
      }
    } catch {
      toast.error('Erro ao buscar produto')
    }
  }

  const buscarProdutos = async (termo: string) => {
    if (!termo.trim()) {
      setProdutosBusca([])
      return
    }
    try {
      const res = await fetch(`/api/painel/pdv/produtos?busca=${encodeURIComponent(termo)}&ativo=true`)
      const data = await res.json()
      if (data.success) {
        setProdutosBusca(data.produtos)
      }
    } catch {
      toast.error('Erro ao buscar produtos')
    }
  }

  const buscarClientes = async (termo: string) => {
    if (!termo.trim()) {
      setClientesEncontrados([])
      return
    }
    try {
      const res = await fetch(`/api/painel/clientes?busca=${encodeURIComponent(termo)}`)
      const data = await res.json()
      if (data.success) {
        setClientesEncontrados(data.clientes || [])
      }
    } catch {
      // Silencioso
    }
  }

  const adicionarItem = (produto: Produto) => {
    const existente = itens.find(item => item.produtoId === produto.id)
    
    if (existente) {
      setItens(itens.map(item =>
        item.id === existente.id
          ? { ...item, quantidade: item.quantidade + 1, total: (item.quantidade + 1) * item.precoUnitario }
          : item
      ))
    } else {
      setItens([...itens, {
        id: Date.now().toString(),
        produtoId: produto.id,
        descricao: produto.nome,
        quantidade: 1,
        precoUnitario: produto.precoVenda,
        total: produto.precoVenda,
        tipo: 'produto'
      }])
    }
    toast.success(`${produto.nome} adicionado`)
  }

  const adicionarItemAvulso = () => {
    if (!avulsaDescricao.trim() || !avulsaValor) {
      toast.error('Preencha descrição e valor')
      return
    }

    const valor = parseFloat(avulsaValor)
    if (isNaN(valor) || valor <= 0) {
      toast.error('Valor inválido')
      return
    }

    setItens([...itens, {
      id: Date.now().toString(),
      descricao: avulsaDescricao.trim(),
      quantidade: 1,
      precoUnitario: valor,
      total: valor,
      tipo: 'avulso'
    }])

    setAvulsaDescricao('')
    setAvulsaValor('')
    setShowVendaAvulsa(false)
    toast.success('Item adicionado')
  }

  const atualizarQuantidade = (itemId: string, novaQuantidade: number) => {
    if (novaQuantidade < 1) {
      removerItem(itemId)
      return
    }

    setItens(itens.map(item =>
      item.id === itemId
        ? { ...item, quantidade: novaQuantidade, total: novaQuantidade * item.precoUnitario }
        : item
    ))
  }

  const removerItem = (itemId: string) => {
    setItens(itens.filter(item => item.id !== itemId))
  }

  const limparCarrinho = () => {
    if (itens.length > 0) {
      if (confirm('Tem certeza que deseja limpar o carrinho?')) {
        setItens([])
        setDesconto(0)
        setClienteSelecionado(null)
      }
    }
  }

  const finalizarVenda = async () => {
    if (!formaPagamento) {
      toast.error('Selecione a forma de pagamento')
      return
    }

    if (formaPagamento === 'dinheiro' && (!valorPago || parseFloat(valorPago) < total)) {
      toast.error('Valor pago insuficiente')
      return
    }

    try {
      const res = await fetch('/api/painel/pdv/vendas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caixaId: caixa?.id,
          itens: itens.map(item => ({
            produtoId: item.produtoId,
            descricao: item.descricao,
            quantidade: item.quantidade,
            precoUnitario: item.precoUnitario,
            tipo: item.tipo
          })),
          desconto,
          formaPagamento,
          valorPago: formaPagamento === 'dinheiro' ? parseFloat(valorPago) : null,
          clienteNome: clienteSelecionado?.nome || null
        })
      })

      const data = await res.json()

      if (data.success) {
        setVendaConcluida({
          ...data.venda,
          clienteNome: clienteSelecionado?.nome || undefined
        })
        setShowPagamento(false)
        setShowVendaConcluida(true)
        setItens([])
        setDesconto(0)
        setValorPago('')
        setFormaPagamento('')
        setClienteSelecionado(null)
        toast.success('Venda realizada com sucesso!')
      } else {
        toast.error(data.error || 'Erro ao finalizar venda')
      }
    } catch {
      toast.error('Erro ao finalizar venda')
    }
  }

  const formatarMoeda = (valor: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor)
  }

  const compartilharVenda = () => {
    if (navigator.share && vendaConcluida) {
      navigator.share({
        title: `Venda #${vendaConcluida.numeroVenda}`,
        text: `Venda realizada no valor de ${formatarMoeda(vendaConcluida.total)}`,
        url: window.location.href
      }).catch(() => {})
    } else {
      navigator.clipboard.writeText(`Venda #${vendaConcluida?.numeroVenda} - Total: ${formatarMoeda(vendaConcluida?.total || 0)}`)
      toast.success('Informações copiadas!')
    }
  }

  const fecharCaixa = async () => {
    if (!saldoFinalInput) {
      toast.error('Informe o saldo final')
      return
    }

    setFechandoCaixa(true)
    try {
      const res = await fetch('/api/painel/pdv/caixa/fechar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caixaId: caixa?.id,
          saldoFinal: parseFloat(saldoFinalInput),
          observacao: observacaoFechamento
        })
      })
      const data = await res.json()
      
      if (data.success) {
        toast.success('Caixa fechado com sucesso!')
        setCaixa(null)
        setShowFecharCaixa(false)
        setSaldoFinalInput('')
        setObservacaoFechamento('')
      } else {
        toast.error(data.error || 'Erro ao fechar caixa')
      }
    } catch {
      toast.error('Erro ao fechar caixa')
    } finally {
      setFechandoCaixa(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  if (!caixa) {
    return (
      <div className="max-w-md mx-auto mt-12">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl flex items-center justify-center gap-2">
              <Banknote className="w-8 h-8 text-emerald-600" />
              Abrir Caixa
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-center text-slate-500 mb-4">
              Não há caixa aberto. Abra o caixa para iniciar as vendas.
            </p>
            <div className="space-y-2">
              <Label>Saldo Inicial</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="0,00"
                defaultValue="0"
                id="saldoInicial"
              />
            </div>
            <Button
              className="w-full h-12 text-lg"
              onClick={() => {
                const input = document.getElementById('saldoInicial') as HTMLInputElement
                abrirCaixa(parseFloat(input.value) || 0)
              }}
            >
              <Check className="w-5 h-5 mr-2" />
              Abrir Caixa
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="h-[calc(100vh-120px)] flex flex-col lg:flex-row gap-4">
      {/* Coluna Esquerda - Produtos */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header com ações */}
        <div className="flex flex-wrap gap-2 mb-4">
          <Button
            variant="outline"
            onClick={() => setShowBarcodeInput(true)}
            className="gap-2"
          >
            <Barcode className="w-4 h-4" />
            Código
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setShowBuscaProdutos(true)
              setTimeout(() => searchInputRef.current?.focus(), 100)
            }}
            className="gap-2"
          >
            <Search className="w-4 h-4" />
            Buscar (F2)
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowVendaAvulsa(true)}
            className="gap-2"
          >
            <Plus className="w-4 h-4" />
            Avulso (F3)
          </Button>
          {itens.length > 0 && (
            <Button
              variant="destructive"
              onClick={limparCarrinho}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Limpar
            </Button>
          )}
          <div className="flex-1" />
          <Button
            variant="outline"
            onClick={() => setShowFecharCaixa(true)}
            className="gap-2 text-red-600 hover:text-red-700"
          >
            <Banknote className="w-4 h-4" />
            Fechar Caixa
          </Button>
        </div>

        {/* Lista de itens do carrinho */}
        <Card className="flex-1 min-h-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              Carrinho
              {itens.length > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {itens.reduce((acc, item) => acc + item.quantidade, 0)} itens
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {itens.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-slate-400">
                <Package className="w-16 h-16 mb-4" />
                <p className="text-lg">Carrinho vazio</p>
                <p className="text-sm">Escaneie ou busque produtos</p>
              </div>
            ) : (
              <ScrollArea className="h-[calc(100vh-400px)]">
                <div className="divide-y">
                  {itens.map((item) => (
                    <div key={item.id} className="p-4 flex items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium truncate">{item.descricao}</p>
                          {item.tipo === 'avulso' && (
                            <Badge variant="outline" className="text-xs">Avulso</Badge>
                          )}
                        </div>
                        <p className="text-sm text-slate-500">
                          {formatarMoeda(item.precoUnitario)} cada
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => atualizarQuantidade(item.id, item.quantidade - 1)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="w-8 text-center font-medium">{item.quantidade}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => atualizarQuantidade(item.id, item.quantidade + 1)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="text-right min-w-[80px]">
                        <p className="font-bold">{formatarMoeda(item.total)}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removerItem(item.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Coluna Direita - Totais e Pagamento */}
      <div className="w-full lg:w-96 flex flex-col gap-4">
        {/* Busca de Cliente */}
        <Card>
          <CardContent className="p-4">
            <Label className="text-sm text-slate-500">Cliente (opcional)</Label>
            <div className="flex gap-2 mt-1">
              <div className="relative flex-1">
                <Input
                  placeholder="Buscar por nome..."
                  value={clienteBusca}
                  onChange={(e) => {
                    setClienteBusca(e.target.value)
                    buscarClientes(e.target.value)
                  }}
                />
                {clientesEncontrados.length > 0 && clienteBusca && (
                  <div className="absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg max-h-48 overflow-y-auto">
                    {clientesEncontrados.map((cliente) => (
                      <button
                        key={cliente.id}
                        className="w-full px-4 py-2 text-left hover:bg-slate-100"
                        onClick={() => {
                          setClienteSelecionado(cliente)
                          setClienteBusca(cliente.nome)
                          setClientesEncontrados([])
                        }}
                      >
                        {cliente.nome}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {clienteSelecionado && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setClienteSelecionado(null)
                    setClienteBusca('')
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
            {clienteSelecionado && (
              <p className="text-sm text-emerald-600 mt-1 flex items-center gap-1">
                <User className="w-3 h-3" />
                {clienteSelecionado.nome}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Total */}
        <Card className="bg-emerald-600 text-white">
          <CardContent className="p-6">
            <p className="text-emerald-100 text-sm">Total</p>
            <p className="text-4xl font-bold">{formatarMoeda(total)}</p>
            {desconto > 0 && (
              <p className="text-emerald-200 text-sm mt-1">
                Desconto: -{formatarMoeda(desconto)}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Desconto */}
        <Card>
          <CardContent className="p-4">
            <Label className="text-sm text-slate-500">Desconto (R$)</Label>
            <Input
              type="number"
              step="0.01"
              value={desconto || ''}
              onChange={(e) => setDesconto(parseFloat(e.target.value) || 0)}
              placeholder="0,00"
              className="mt-1"
            />
          </CardContent>
        </Card>

        {/* Botões de navegação */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            className="h-16"
            onClick={() => router.push('/painel/pdv/produtos')}
          >
            <Package className="w-5 h-5 mr-2" />
            Produtos
          </Button>
          <Button
            variant="outline"
            className="h-16"
            onClick={() => router.push('/painel/pdv/vendas')}
          >
            <Receipt className="w-5 h-5 mr-2" />
            Vendas
          </Button>
        </div>

        {/* Botão Finalizar */}
        <Button
          className="h-20 text-xl font-bold"
          disabled={itens.length === 0}
          onClick={() => setShowPagamento(true)}
        >
          <CreditCard className="w-6 h-6 mr-2" />
          Finalizar Venda (F4)
        </Button>
      </div>

      {/* Modal de Código de Barras */}
      <Dialog open={showBarcodeInput} onOpenChange={setShowBarcodeInput}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Ler Código de Barras</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              ref={barcodeInputRef}
              placeholder="Escaneie ou digite o código..."
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  const value = (e.target as HTMLInputElement).value
                  if (value.trim()) {
                    buscarProdutoPorCodigo(value.trim())
                    setShowBarcodeInput(false)
                  }
                }
              }}
              autoFocus
            />
            <p className="text-sm text-slate-500 text-center">
              Posicione o leitor e escaneie o código
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Sheet de Busca de Produtos */}
      <Sheet open={showBuscaProdutos} onOpenChange={setShowBuscaProdutos}>
        <SheetContent>
          <SheetHeader>
            <SheetTitle>Buscar Produtos</SheetTitle>
          </SheetHeader>
          <div className="space-y-4 mt-4">
            <Input
              ref={searchInputRef}
              placeholder="Buscar por nome ou código..."
              value={busca}
              onChange={(e) => {
                setBusca(e.target.value)
                buscarProdutos(e.target.value)
              }}
            />
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-2">
                {produtosBusca.map((produto) => (
                  <Card 
                    key={produto.id} 
                    className="cursor-pointer hover:bg-emerald-50 transition-colors"
                    onClick={() => {
                      adicionarItem(produto)
                      setShowBuscaProdutos(false)
                      setBusca('')
                      setProdutosBusca([])
                    }}
                  >
                    <CardContent className="p-3">
                      <p className="font-medium">{produto.nome}</p>
                      <div className="flex justify-between text-sm text-slate-500">
                        <span>Estoque: {produto.estoque}</span>
                        <span className="font-bold text-emerald-600">{formatarMoeda(produto.precoVenda)}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {busca && produtosBusca.length === 0 && (
                  <p className="text-center text-slate-400 py-8">
                    Nenhum produto encontrado
                  </p>
                )}
              </div>
            </ScrollArea>
          </div>
        </SheetContent>
      </Sheet>

      {/* Modal de Venda Avulsa */}
      <Dialog open={showVendaAvulsa} onOpenChange={setShowVendaAvulsa}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Venda Avulsa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Descrição</Label>
              <Input
                value={avulsaDescricao}
                onChange={(e) => setAvulsaDescricao(e.target.value)}
                placeholder="Ex: Serviço de instalação"
              />
            </div>
            <div className="space-y-2">
              <Label>Valor (R$)</Label>
              <Input
                type="number"
                step="0.01"
                value={avulsaValor}
                onChange={(e) => setAvulsaValor(e.target.value)}
                placeholder="0,00"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowVendaAvulsa(false)}>
              Cancelar
            </Button>
            <Button onClick={adicionarItemAvulso}>
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Pagamento */}
      <Dialog open={showPagamento} onOpenChange={setShowPagamento}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Finalizar Venda</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Resumo */}
            <div className="bg-slate-50 rounded-lg p-4">
              <div className="flex justify-between text-sm">
                <span>Itens:</span>
                <span>{itens.reduce((acc, item) => acc + item.quantidade, 0)}</span>
              </div>
              <div className="flex justify-between font-bold text-xl mt-2">
                <span>Total:</span>
                <span className="text-emerald-600">{formatarMoeda(total)}</span>
              </div>
            </div>

            {/* Forma de pagamento */}
            <div className="space-y-2">
              <Label>Forma de Pagamento</Label>
              <div className="grid grid-cols-2 gap-2">
                {formasPagamento.map((forma) => (
                  <Button
                    key={forma.value}
                    variant={formaPagamento === forma.value ? 'default' : 'outline'}
                    className={`h-16 ${formaPagamento === forma.value ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
                    onClick={() => setFormaPagamento(forma.value)}
                  >
                    <forma.icon className="w-5 h-5 mr-2" />
                    {forma.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Valor pago (dinheiro) */}
            {formaPagamento === 'dinheiro' && (
              <div className="space-y-2">
                <Label>Valor Pago (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={valorPago}
                  onChange={(e) => setValorPago(e.target.value)}
                  placeholder="0,00"
                />
                {valorPago && parseFloat(valorPago) >= total && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                    <span className="text-amber-700">Troco: </span>
                    <span className="font-bold text-amber-700">{formatarMoeda(troco)}</span>
                  </div>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPagamento(false)}>
              Cancelar
            </Button>
            <Button onClick={finalizarVenda} className="bg-emerald-600 hover:bg-emerald-700">
              <Check className="w-4 h-4 mr-2" />
              Confirmar Venda
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Venda Concluída */}
      <Dialog open={showVendaConcluida} onOpenChange={setShowVendaConcluida}>
        <DialogContent className="sm:max-w-md text-center">
          <DialogHeader>
            <DialogTitle className="text-2xl text-emerald-600">Venda Concluída!</DialogTitle>
          </DialogHeader>
          
          <div className="py-6">
            <div className="w-20 h-20 mx-auto mb-4 bg-emerald-100 rounded-full flex items-center justify-center">
              <Check className="w-10 h-10 text-emerald-600" />
            </div>
            <p className="text-lg text-slate-600 mb-2">
              Venda #{vendaConcluida?.numeroVenda}
            </p>
            <p className="text-4xl font-bold text-emerald-600">
              {formatarMoeda(vendaConcluida?.total || 0)}
            </p>
          </div>

          <div className="flex justify-center gap-2 mb-4">
            <Button
              variant="outline"
              className="gap-2"
              onClick={compartilharVenda}
            >
              <Share2 className="w-4 h-4" />
              Compartilhar
            </Button>
          </div>

          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              className="flex-1 gap-2"
              onClick={() => {
                if (vendaConcluida) {
                  window.open(`/painel/pdv/recibo/${vendaConcluida.id}`, '_blank')
                }
              }}
            >
              <Printer className="w-4 h-4" />
              Recibo
            </Button>
            <Button
              className="flex-1 bg-emerald-600 hover:bg-emerald-700"
              onClick={() => {
                setShowVendaConcluida(false)
                setVendaConcluida(null)
              }}
            >
              Nova Venda
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Fechar Caixa */}
      <Dialog open={showFecharCaixa} onOpenChange={setShowFecharCaixa}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Fechar Caixa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-lg p-4 space-y-2">
              <p className="text-sm text-slate-500">Saldo Inicial</p>
              <p className="text-xl font-bold">{formatarMoeda(caixa?.saldoInicial || 0)}</p>
            </div>
            <div className="space-y-2">
              <Label>Saldo Final em Caixa (R$)</Label>
              <Input
                type="number"
                step="0.01"
                value={saldoFinalInput}
                onChange={(e) => setSaldoFinalInput(e.target.value)}
                placeholder="0,00"
              />
            </div>
            <div className="space-y-2">
              <Label>Observação (opcional)</Label>
              <Input
                value={observacaoFechamento}
                onChange={(e) => setObservacaoFechamento(e.target.value)}
                placeholder="Observações..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFecharCaixa(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={fecharCaixa} 
              disabled={fechandoCaixa}
              className="bg-red-600 hover:bg-red-700"
            >
              {fechandoCaixa ? 'Fechando...' : 'Fechar Caixa'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Caixa Existente */}
      <Dialog open={showCaixaExistente} onOpenChange={setShowCaixaExistente}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-600">
              <AlertTriangle className="w-5 h-5" />
              Já existe um caixa aberto
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <p className="text-sm text-amber-800">
                Já existe um caixa aberto para esta loja. Deseja fechar o caixa atual e abrir um novo?
              </p>
            </div>
            <div className="bg-slate-50 rounded-lg p-4 space-y-2">
              <p className="text-sm text-slate-500">Caixa Atual</p>
              <p className="font-medium">Saldo Inicial: {formatarMoeda(caixa?.saldoInicial || 0)}</p>
            </div>
            <div className="bg-emerald-50 rounded-lg p-4 space-y-2">
              <p className="text-sm text-emerald-700">Novo Caixa</p>
              <p className="font-medium">Saldo Inicial: {formatarMoeda(novoSaldoInicial)}</p>
            </div>
          </div>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button 
              variant="outline" 
              onClick={() => setShowCaixaExistente(false)}
              className="w-full sm:w-auto"
            >
              Manter Caixa Atual
            </Button>
            <Button 
              onClick={fecharEAbrirNovoCaixa} 
              disabled={fechandoCaixa}
              className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700"
            >
              {fechandoCaixa ? 'Processando...' : 'Fechar Atual e Abrir Novo'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

'use client'

import { useEffect, useState, useRef } from 'react'
import { useParams } from 'next/navigation'
import { Printer, FileText, ArrowLeft, Check, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface ItemVenda {
  id: string
  descricao: string
  quantidade: number
  precoUnitario: number
  total: number
  tipo: string
}

interface Venda {
  id: string
  numeroVenda: number
  clienteNome: string | null
  subtotal: number
  desconto: number
  total: number
  formaPagamento: string
  valorPago: number | null
  troco: number | null
  status: string
  dataVenda: string
  itens: ItemVenda[]
}

interface LojaInfo {
  nome: string
  endereco: string
  telefone: string
}

export default function ReciboPage() {
  const params = useParams()
  const vendaId = params.id as string
  
  const [venda, setVenda] = useState<Venda | null>(null)
  const [loja, setLoja] = useState<LojaInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [tipoImpressao, setTipoImpressao] = useState<'termica' | 'a4'>('termica')
  const [tamanhoTermica, setTamanhoTermica] = useState<'58mm' | '80mm'>('80mm')
  const [impressaoPronta, setImpressaoPronta] = useState(false)
  const reciboRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    loadVenda()
    loadLoja()
  }, [vendaId])

  const loadVenda = async () => {
    try {
      const res = await fetch(`/api/painel/pdv/vendas/${vendaId}`)
      const data = await res.json()
      if (data.success) {
        setVenda(data.venda)
      }
    } catch {
      console.error('Erro ao carregar venda')
    } finally {
      setLoading(false)
    }
  }

  const loadLoja = async () => {
    try {
      const res = await fetch('/api/painel/configuracoes')
      const data = await res.json()
      if (data.success && data.loja) {
        setLoja({
          nome: data.loja.nome || 'TecOS PDV',
          endereco: data.loja.endereco || '',
          telefone: data.loja.telefone || ''
        })
      }
    } catch {
      // Silencioso
    }
  }

  const formatarMoeda = (valor: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor)
  }

  const formatarFormaPagamento = (forma: string) => {
    const formas: Record<string, string> = {
      dinheiro: 'Dinheiro',
      pix: 'PIX',
      cartao_credito: 'Cartão Crédito',
      cartao_debito: 'Cartão Débito'
    }
    return formas[forma] || forma
  }

  const imprimir = () => {
    setImpressaoPronta(true)
    setTimeout(() => {
      window.print()
    }, 100)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 print:bg-white">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  if (!venda) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <X className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-xl font-bold mb-2">Venda não encontrada</h1>
            <p className="text-slate-500 mb-4">O recibo solicitado não existe ou foi removido.</p>
            <Button variant="outline" onClick={() => window.close()}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const dadosLoja = loja || { nome: 'TecOS PDV', endereco: '', telefone: '' }

  return (
    <div className="min-h-screen bg-slate-100 print:bg-white p-4">
      {/* Controles - Ocultos na impressão */}
      <div className="max-w-4xl mx-auto mb-4 print:hidden">
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Tipo:</span>
                <div className="flex gap-2">
                  <Button
                    variant={tipoImpressao === 'termica' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTipoImpressao('termica')}
                    className={tipoImpressao === 'termica' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
                  >
                    <Printer className="w-4 h-4 mr-1" />
                    Térmica
                  </Button>
                  <Button
                    variant={tipoImpressao === 'a4' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTipoImpressao('a4')}
                    className={tipoImpressao === 'a4' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
                  >
                    <FileText className="w-4 h-4 mr-1" />
                    A4
                  </Button>
                </div>
              </div>

              {tipoImpressao === 'termica' && (
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">Tamanho:</span>
                  <Select value={tamanhoTermica} onValueChange={(v) => setTamanhoTermica(v as '58mm' | '80mm')}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="80mm">80mm</SelectItem>
                      <SelectItem value="58mm">58mm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex-1" />

              <Button onClick={imprimir} className="bg-emerald-600 hover:bg-emerald-700">
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Área do Recibo */}
      <div className="max-w-4xl mx-auto">
        {tipoImpressao === 'a4' ? (
          <ReciboA4 
            venda={venda} 
            loja={dadosLoja} 
            formatarMoeda={formatarMoeda}
            formatarFormaPagamento={formatarFormaPagamento}
          />
        ) : (
          <ReciboTermica 
            venda={venda} 
            loja={dadosLoja} 
            tamanhoTermica={tamanhoTermica}
            formatarMoeda={formatarMoeda}
            formatarFormaPagamento={formatarFormaPagamento}
          />
        )}
      </div>

      {/* Estilos de impressão */}
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print-area,
          .print-area * {
            visibility: visible;
          }
          .print-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          
          @page {
            size: auto;
            margin: 0;
          }
        }
      `}</style>
    </div>
  )
}

// Componente de Recibo A4
function ReciboA4({ 
  venda, 
  loja, 
  formatarMoeda, 
  formatarFormaPagamento 
}: { 
  venda: Venda
  loja: LojaInfo
  formatarMoeda: (v: number) => string
  formatarFormaPagamento: (f: string) => string
}) {
  return (
    <div className="print-area bg-white p-8 rounded-lg shadow-sm" style={{ 
      fontFamily: 'Arial, sans-serif',
      width: '297mm',
      minHeight: '210mm',
      boxSizing: 'border-box',
      margin: '0 auto'
    }}>
      {/* Cabeçalho */}
      <div style={{ 
        borderBottom: '3px solid #059669', 
        paddingBottom: '15px',
        marginBottom: '20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start'
      }}>
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: 'bold', color: '#059669', margin: 0 }}>{loja.nome}</h1>
          {loja.endereco && <p style={{ fontSize: '12px', color: '#64748b', margin: '5px 0' }}>{loja.endereco}</p>}
          {loja.telefone && <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>{loja.telefone}</p>}
        </div>
        <div style={{ textAlign: 'right' }}>
          <h2 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0, color: '#374151' }}>COMPROVANTE DE VENDA</h2>
          <p style={{ fontSize: '14px', fontWeight: 'bold', color: '#059669', margin: '5px 0' }}>Venda #{venda.numeroVenda}</p>
          <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>
            {new Date(venda.dataVenda).toLocaleString('pt-BR')}
          </p>
        </div>
      </div>

      {/* Cliente */}
      {venda.clienteNome && (
        <div style={{ 
          backgroundColor: '#f8fafc', 
          padding: '10px 15px', 
          borderRadius: '5px',
          marginBottom: '15px'
        }}>
          <span style={{ fontWeight: 'bold' }}>Cliente:</span> {venda.clienteNome}
        </div>
      )}

      {/* Tabela de Produtos */}
      <table style={{ 
        width: '100%', 
        borderCollapse: 'collapse',
        marginBottom: '20px'
      }}>
        <thead>
          <tr style={{ backgroundColor: '#059669', color: 'white' }}>
            <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '2px solid #047857' }}>Item</th>
            <th style={{ padding: '12px 15px', textAlign: 'center', width: '80px', borderBottom: '2px solid #047857' }}>Qtd</th>
            <th style={{ padding: '12px 15px', textAlign: 'right', width: '120px', borderBottom: '2px solid #047857' }}>Unitário</th>
            <th style={{ padding: '12px 15px', textAlign: 'right', width: '120px', borderBottom: '2px solid #047857' }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {venda.itens.map((item, idx) => (
            <tr key={item.id} style={{ backgroundColor: idx % 2 === 0 ? '#fff' : '#f8fafc' }}>
              <td style={{ padding: '12px 15px', borderBottom: '1px solid #e2e8f0' }}>
                <span style={{ fontWeight: '500' }}>{item.descricao}</span>
                {item.tipo === 'avulso' && (
                  <span style={{ 
                    fontSize: '10px', 
                    backgroundColor: '#fef3c7', 
                    padding: '2px 6px', 
                    borderRadius: '3px',
                    marginLeft: '8px'
                  }}>Avulso</span>
                )}
              </td>
              <td style={{ padding: '12px 15px', textAlign: 'center', borderBottom: '1px solid #e2e8f0' }}>{item.quantidade}</td>
              <td style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #e2e8f0' }}>{formatarMoeda(item.precoUnitario)}</td>
              <td style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #e2e8f0', fontWeight: 'bold' }}>{formatarMoeda(item.total)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Totais */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '20px' }}>
        <div style={{ width: '300px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', fontSize: '14px' }}>
            <span>Subtotal:</span>
            <span>{formatarMoeda(venda.subtotal)}</span>
          </div>
          {venda.desconto > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', color: '#dc2626', fontSize: '14px' }}>
              <span>Desconto:</span>
              <span>-{formatarMoeda(venda.desconto)}</span>
            </div>
          )}
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            padding: '12px 15px', 
            backgroundColor: '#059669', 
            color: 'white',
            fontSize: '20px',
            fontWeight: 'bold',
            borderRadius: '5px',
            marginTop: '8px'
          }}>
            <span>TOTAL:</span>
            <span>{formatarMoeda(venda.total)}</span>
          </div>
        </div>
      </div>

      {/* Pagamento */}
      <div style={{ 
        backgroundColor: '#f8fafc', 
        padding: '15px 20px', 
        borderRadius: '5px',
        marginBottom: '20px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
          <span style={{ fontWeight: 'bold' }}>Forma de Pagamento:</span>
          <span>{formatarFormaPagamento(venda.formaPagamento)}</span>
        </div>
        {venda.valorPago && (
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ fontWeight: 'bold' }}>Valor Pago:</span>
            <span>{formatarMoeda(venda.valorPago)}</span>
          </div>
        )}
        {venda.troco && venda.troco > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#ea580c', fontWeight: 'bold' }}>
            <span>Troco:</span>
            <span>{formatarMoeda(venda.troco)}</span>
          </div>
        )}
      </div>

      {/* Assinatura */}
      <div style={{ marginTop: '40px', paddingTop: '20px', borderTop: '1px solid #e2e8f0' }}>
        <div style={{ width: '300px', margin: '0 auto', textAlign: 'center' }}>
          <div style={{ borderBottom: '1px solid #000', marginBottom: '5px' }}></div>
          <span style={{ fontSize: '12px', color: '#64748b' }}>Assinatura do Cliente</span>
        </div>
      </div>

      {/* Rodapé */}
      <div style={{ 
        textAlign: 'center', 
        marginTop: '30px',
        paddingTop: '15px',
        borderTop: '1px solid #e2e8f0',
        color: '#64748b',
        fontSize: '11px'
      }}>
        <p>Obrigado pela preferência!</p>
        <p>TecOS - Sistema de Gestão para Assistências Técnicas</p>
      </div>
    </div>
  )
}

// Componente de Recibo Térmica
function ReciboTermica({ 
  venda, 
  loja, 
  tamanhoTermica,
  formatarMoeda, 
  formatarFormaPagamento 
}: { 
  venda: Venda
  loja: LojaInfo
  tamanhoTermica: '58mm' | '80mm'
  formatarMoeda: (v: number) => string
  formatarFormaPagamento: (f: string) => string
}) {
  const largura = tamanhoTermica === '58mm' ? '58mm' : '80mm'
  const fontSize = tamanhoTermica === '58mm' ? '10px' : '12px'

  return (
    <div className="print-area bg-white rounded-lg shadow-sm mx-auto p-4" style={{ 
      fontFamily: "'Courier New', monospace', monospace",
      fontSize,
      width: largura,
      maxWidth: '400px',
      margin: '0 auto'
    }}>
      {/* Cabeçalho */}
      <div style={{ textAlign: 'center', marginBottom: '10px' }}>
        <div style={{ fontSize: '16px', fontWeight: 'bold' }}>{loja.nome}</div>
        <div style={{ fontSize: '10px', color: '#666' }}>CUPOM NÃO FISCAL</div>
      </div>
      <div style={{ borderTop: '1px dashed #000', margin: '8px 0' }}></div>

      {/* Informações */}
      <div style={{ fontSize: '11px' }}>
        <div><strong>Venda:</strong> #{venda.numeroVenda}</div>
        <div><strong>Data:</strong> {new Date(venda.dataVenda).toLocaleString('pt-BR')}</div>
        {venda.clienteNome && <div><strong>Cliente:</strong> {venda.clienteNome}</div>}
        {loja.endereco && <div><strong>End:</strong> {loja.endereco}</div>}
        {loja.telefone && <div><strong>Tel:</strong> {loja.telefone}</div>}
      </div>
      <div style={{ borderTop: '1px dashed #000', margin: '8px 0' }}></div>

      {/* Cabeçalho Itens */}
      <div style={{ fontSize: '10px', fontWeight: 'bold', display: 'flex', borderBottom: '1px solid #ccc', paddingBottom: '4px' }}>
        <div style={{ flex: 1 }}>ITEM</div>
        <div style={{ width: '40px', textAlign: 'center' }}>QTD</div>
        <div style={{ width: '60px', textAlign: 'right' }}>UNIT</div>
        <div style={{ width: '60px', textAlign: 'right' }}>TOTAL</div>
      </div>

      {/* Itens */}
      {venda.itens.map((item, idx) => (
        <div key={item.id} style={{ fontSize: '11px', display: 'flex', padding: '3px 0', borderBottom: '1px dotted #eee' }}>
          <div style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {idx + 1}. {item.descricao.substring(0, 16)}
          </div>
          <div style={{ width: '40px', textAlign: 'center' }}>{item.quantidade}</div>
          <div style={{ width: '60px', textAlign: 'right' }}>{formatarMoeda(item.precoUnitario)}</div>
          <div style={{ width: '60px', textAlign: 'right' }}>{formatarMoeda(item.total)}</div>
        </div>
      ))}

      <div style={{ borderTop: '1px dashed #000', margin: '8px 0' }}></div>

      {/* Totais */}
      <div style={{ fontSize: '11px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>Subtotal:</span>
          <span>{formatarMoeda(venda.subtotal)}</span>
        </div>
        {venda.desconto > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#dc2626' }}>
            <span>Desconto:</span>
            <span>-{formatarMoeda(venda.desconto)}</span>
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: 'bold', marginTop: '4px' }}>
          <span>TOTAL:</span>
          <span>{formatarMoeda(venda.total)}</span>
        </div>
      </div>
      <div style={{ borderTop: '1px dashed #000', margin: '8px 0' }}></div>

      {/* Pagamento */}
      <div style={{ fontSize: '11px' }}>
        <div><strong>Forma:</strong> {formatarFormaPagamento(venda.formaPagamento)}</div>
        {venda.valorPago && <div><strong>Pago:</strong> {formatarMoeda(venda.valorPago)}</div>}
        {venda.troco && venda.troco > 0 && (
          <div style={{ color: '#ea580c', fontWeight: 'bold' }}><strong>Troco:</strong> {formatarMoeda(venda.troco)}</div>
        )}
      </div>
      <div style={{ borderTop: '1px dashed #000', margin: '8px 0' }}></div>

      {/* Rodapé */}
      <div style={{ textAlign: 'center', fontSize: '10px', color: '#666' }}>
        <div>Obrigado pela preferência!</div>
        <div>TecOS - Sistema de Gestão</div>
      </div>
    </div>
  )
}

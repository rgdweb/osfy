'use client'

import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import {
  ShoppingCart,
  Search,
  Plus,
  Minus,
  Trash2,
  CreditCard,
  Banknote,
  QrCode,
  Package,
  X,
  Check,
  Barcode,
  Wallet,
  User,
  Printer,
  FileText,
  Receipt
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'

interface Produto {
  id: string
  nome: string
  codigoBarras: string | null
  precoVenda: number
  estoque: number
  categoria?: { nome: string } | null
}

interface ItemCarrinho {
  id: string
  produtoId?: string
  descricao: string
  quantidade: number
  precoUnitario: number
  total: number
  tipo: 'produto' | 'avulso'
}

interface Caixa {
  id: string
  status: string
  saldoInicial: number
}

interface VendaRealizada {
  id: string
  numeroVenda: number
  subtotal: number
  desconto: number
  total: number
  formaPagamento: string
  valorPago: number | null
  troco: number | null
  clienteNome?: string
  itens: Array<{
    descricao: string
    quantidade: number
    precoUnitario: number
    total: number
  }>
}

interface LojaInfo {
  nome: string
  endereco: string
  telefone: string
}

const formasPagamento = [
  { value: 'dinheiro', label: 'Dinheiro', icon: Banknote },
  { value: 'pix', label: 'PIX', icon: QrCode },
  { value: 'cartao_credito', label: 'Cartão Crédito', icon: CreditCard },
  { value: 'cartao_debito', label: 'Cartão Débito', icon: CreditCard },
]

export default function FrenteDeCaixa() {
  const router = useRouter()
  const barcodeInputRef = useRef<HTMLInputElement>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)

  // Estados do PDV
  const [caixa, setCaixa] = useState<Caixa | null>(null)
  const [loja, setLoja] = useState<LojaInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [barcodeBuffer, setBarcodeBuffer] = useState('')
  const [showBarcodeInput, setShowBarcodeInput] = useState(false)

  // Estados do carrinho
  const [itens, setItens] = useState<ItemCarrinho[]>([])
  const [desconto, setDesconto] = useState(0)

  // Estados de busca
  const [busca, setBusca] = useState('')
  const [produtosBusca, setProdutosBusca] = useState<Produto[]>([])
  const [showBuscaProdutos, setShowBuscaProdutos] = useState(false)

  // Estados de pagamento
  const [showPagamento, setShowPagamento] = useState(false)
  const [formaPagamento, setFormaPagamento] = useState('')
  const [valorPago, setValorPago] = useState('')
  const [clienteNome, setClienteNome] = useState('')

  // Estados de venda avulsa
  const [showVendaAvulsa, setShowVendaAvulsa] = useState(false)
  const [avulsaDescricao, setAvulsaDescricao] = useState('')
  const [avulsaValor, setAvulsaValor] = useState('')

  // Estado da última venda e cupom
  const [ultimaVenda, setUltimaVenda] = useState<VendaRealizada | null>(null)
  const [showCupom, setShowCupom] = useState(false)
  
  // Estados de impressão - SELEÇÃO NO MOMENTO DA IMPRESSÃO
  const [showImpressao, setShowImpressao] = useState(false)
  const [tipoImpressao, setTipoImpressao] = useState<'termica' | 'a4'>('termica')
  const [tamanhoTermica, setTamanhoTermica] = useState<'58mm' | '80mm'>('80mm')

  // Estados de fechar caixa
  const [showFecharCaixa, setShowFecharCaixa] = useState(false)
  const [saldoFinalInput, setSaldoFinalInput] = useState('')
  const [observacaoFechamento, setObservacaoFechamento] = useState('')
  const [fechandoCaixa, setFechandoCaixa] = useState(false)
  const [resumoFechamento, setResumoFechamento] = useState<{
    totalVendas: number
    totalDinheiro: number
    totalPix: number
    totalCartaoCredito: number
    totalCartaoDebito: number
  } | null>(null)

  // Estado para caixa existente ao tentar abrir novo
  const [showCaixaExistente, setShowCaixaExistente] = useState(false)
  const [novoSaldoInicial, setNovoSaldoInicial] = useState(0)

  // Calcular totais
  const subtotal = itens.reduce((acc, item) => acc + item.total, 0)
  const total = subtotal - desconto
  const troco = valorPago && parseFloat(valorPago) > total ? parseFloat(valorPago) - total : 0

  // Carregar caixa e loja
  useEffect(() => {
    loadCaixa()
    loadLoja()
  }, [])

  // Listener para código de barras via keyboard
  useEffect(() => {
    let timeoutId: NodeJS.Timeout

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return
      }

      // F2 abre busca de produtos
      if (e.key === 'F2') {
        e.preventDefault()
        setShowBuscaProdutos(true)
        setTimeout(() => searchInputRef.current?.focus(), 100)
        return
      }

      // F3 abre venda avulsa
      if (e.key === 'F3') {
        e.preventDefault()
        setShowVendaAvulsa(true)
        return
      }

      // F4 abre pagamento
      if (e.key === 'F4') {
        e.preventDefault()
        if (itens.length > 0) {
          setShowPagamento(true)
        }
        return
      }

      // Enter processa o buffer como código de barras
      if (e.key === 'Enter' && barcodeBuffer.length > 3) {
        e.preventDefault()
        buscarProdutoPorCodigo(barcodeBuffer)
        setBarcodeBuffer('')
        return
      }

      // Acumular caracteres para código de barras
      if (e.key.length === 1) {
        setBarcodeBuffer(prev => {
          const newBuffer = prev + e.key
          clearTimeout(timeoutId)
          timeoutId = setTimeout(() => setBarcodeBuffer(''), 50)
          return newBuffer
        })
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      clearTimeout(timeoutId)
    }
  }, [barcodeBuffer, itens.length])

  const loadCaixa = async () => {
    try {
      const res = await fetch('/api/painel/pdv/caixa')
      const data = await res.json()
      if (data.success) {
        // A API retorna caixaAberto, não caixa
        setCaixa(data.caixaAberto || null)
      }
    } catch {
      toast.error('Erro ao carregar caixa')
    } finally {
      setLoading(false)
    }
  }

  const loadLoja = async () => {
    try {
      const res = await fetch('/api/painel/configuracoes')
      const data = await res.json()
      if (data.success && data.loja) {
        setLoja({
          nome: data.loja.nome || 'TecOS PDV',
          endereco: data.loja.endereco || '',
          telefone: data.loja.telefone || ''
        })
      }
    } catch {
      // Silencioso
    }
  }

  const abrirCaixa = async (saldoInicial: number) => {
    try {
      // Primeiro verificar se já existe um caixa aberto
      const checkRes = await fetch('/api/painel/pdv/caixa')
      const checkData = await checkRes.json()
      
      if (checkData.success && checkData.caixaAberto) {
        // Já existe um caixa aberto - mostrar opção
        setNovoSaldoInicial(saldoInicial)
        setShowCaixaExistente(true)
        return
      }

      const res = await fetch('/api/painel/pdv/caixa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saldoInicial })
      })
      const data = await res.json()
      if (data.success) {
        setCaixa(data.caixa)
        toast.success('Caixa aberto com sucesso!')
      } else {
        toast.error(data.error || 'Erro ao abrir caixa')
      }
    } catch {
      toast.error('Erro ao abrir caixa')
    }
  }

  // Fechar caixa atual e abrir novo
  const fecharEAbrirNovoCaixa = async () => {
    if (!caixa) return
    
    setFechandoCaixa(true)
    try {
      // 1. Fechar o caixa atual
      const fecharRes = await fetch('/api/painel/pdv/caixa/fechar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caixaId: caixa.id,
          saldoFinal: caixa.saldoInicial, // Usar saldo inicial como base
          observacao: 'Fechado automaticamente para abrir novo caixa'
        })
      })
      const fecharData = await fecharRes.json()
      
      if (!fecharData.success) {
        toast.error('Erro ao fechar caixa anterior')
        return
      }

      // 2. Abrir novo caixa
      const abrirRes = await fetch('/api/painel/pdv/caixa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saldoInicial: novoSaldoInicial })
      })
      const abrirData = await abrirRes.json()
      
      if (abrirData.success) {
        setCaixa(abrirData.caixa)
        setShowCaixaExistente(false)
        toast.success('Caixa anterior fechado e novo caixa aberto!')
      } else {
        toast.error(abrirData.error || 'Erro ao abrir novo caixa')
      }
    } catch {
      toast.error('Erro ao processar operação')
    } finally {
      setFechandoCaixa(false)
    }
  }

  const buscarProdutoPorCodigo = async (codigo: string) => {
    try {
      const res = await fetch(`/api/painel/pdv/produtos?codigo_barras=${encodeURIComponent(codigo)}`)
      const data = await res.json()
      
      if (data.success && data.produto) {
        adicionarItem(data.produto)
      } else {
        toast.error('Produto não encontrado')
      }
    } catch {
      toast.error('Erro ao buscar produto')
    }
  }

  const buscarProdutos = async (termo: string) => {
    if (!termo.trim()) {
      setProdutosBusca([])
      return
    }
    try {
      const res = await fetch(`/api/painel/pdv/produtos?busca=${encodeURIComponent(termo)}&ativo=true`)
      const data = await res.json()
      if (data.success) {
        setProdutosBusca(data.produtos)
      }
    } catch {
      toast.error('Erro ao buscar produtos')
    }
  }

  const adicionarItem = (produto: Produto) => {
    const existente = itens.find(item => item.produtoId === produto.id)
    
    if (existente) {
      setItens(itens.map(item =>
        item.id === existente.id
          ? { ...item, quantidade: item.quantidade + 1, total: (item.quantidade + 1) * item.precoUnitario }
          : item
      ))
    } else {
      setItens([...itens, {
        id: Date.now().toString(),
        produtoId: produto.id,
        descricao: produto.nome,
        quantidade: 1,
        precoUnitario: produto.precoVenda,
        total: produto.precoVenda,
        tipo: 'produto'
      }])
    }
    toast.success(`${produto.nome} adicionado`)
  }

  const adicionarItemAvulso = () => {
    if (!avulsaDescricao.trim() || !avulsaValor) {
      toast.error('Preencha descrição e valor')
      return
    }

    const valor = parseFloat(avulsaValor)
    if (isNaN(valor) || valor <= 0) {
      toast.error('Valor inválido')
      return
    }

    setItens([...itens, {
      id: Date.now().toString(),
      descricao: avulsaDescricao.trim(),
      quantidade: 1,
      precoUnitario: valor,
      total: valor,
      tipo: 'avulso'
    }])

    setAvulsaDescricao('')
    setAvulsaValor('')
    setShowVendaAvulsa(false)
    toast.success('Item adicionado')
  }

  const atualizarQuantidade = (itemId: string, novaQuantidade: number) => {
    if (novaQuantidade < 1) {
      removerItem(itemId)
      return
    }

    setItens(itens.map(item =>
      item.id === itemId
        ? { ...item, quantidade: novaQuantidade, total: novaQuantidade * item.precoUnitario }
        : item
    ))
  }

  const removerItem = (itemId: string) => {
    setItens(itens.filter(item => item.id !== itemId))
  }

  const limparCarrinho = () => {
    setItens([])
    setDesconto(0)
  }

  const finalizarVenda = async () => {
    if (!formaPagamento) {
      toast.error('Selecione a forma de pagamento')
      return
    }

    if (formaPagamento === 'dinheiro' && (!valorPago || parseFloat(valorPago) < total)) {
      toast.error('Valor pago insuficiente')
      return
    }

    try {
      const res = await fetch('/api/painel/pdv/vendas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caixaId: caixa?.id,
          itens: itens.map(item => ({
            produtoId: item.produtoId,
            descricao: item.descricao,
            quantidade: item.quantidade,
            precoUnitario: item.precoUnitario,
            tipo: item.tipo
          })),
          desconto,
          formaPagamento,
          valorPago: formaPagamento === 'dinheiro' ? parseFloat(valorPago) : null,
          clienteNome: clienteNome || null
        })
      })

      const data = await res.json()

      if (data.success) {
        setUltimaVenda({
          ...data.venda,
          clienteNome: clienteNome || undefined
        })
        setShowPagamento(false)
        setShowCupom(true)
        limparCarrinho()
        setValorPago('')
        setClienteNome('')
        setFormaPagamento('')
        toast.success('Venda realizada com sucesso!')
      } else {
        toast.error(data.error || 'Erro ao finalizar venda')
      }
    } catch {
      toast.error('Erro ao finalizar venda')
    }
  }

  const formatarMoeda = (valor: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor)
  }

  // ====== PRÉ-VISUALIZAÇÃO DO RECIBO ======
  const gerarPreviewRecibo = () => {
    const dadosLoja = loja || { nome: 'TecOS PDV', endereco: '', telefone: '' }
    const largura = tipoImpressao === 'a4' ? '210mm' : tamanhoTermica
    
    return `
      <div style="font-family: 'Courier New', monospace; font-size: 12px; width: ${tipoImpressao === 'a4' ? '100%' : largura}; max-width: 400px; margin: 0 auto; padding: 10px; background: white; border: 1px solid #ddd;">
        <div style="text-align: center; margin-bottom: 10px;">
          <div style="font-size: 16px; font-weight: bold;">${dadosLoja.nome}</div>
          <div style="font-size: 10px; color: #666;">CUPOM NÃO FISCAL</div>
        </div>
        <div style="border-top: 1px dashed #000; margin: 8px 0;"></div>
        <div style="font-size: 11px;">
          <div><strong>Venda:</strong> #${ultimaVenda?.numeroVenda || '0001'}</div>
          <div><strong>Data:</strong> ${new Date().toLocaleString('pt-BR')}</div>
          ${clienteNome ? `<div><strong>Cliente:</strong> ${clienteNome}</div>` : ''}
          ${dadosLoja.endereco ? `<div><strong>End:</strong> ${dadosLoja.endereco}</div>` : ''}
          ${dadosLoja.telefone ? `<div><strong>Tel:</strong> ${dadosLoja.telefone}</div>` : ''}
        </div>
        <div style="border-top: 1px dashed #000; margin: 8px 0;"></div>
        
        <!-- Cabeçalho dos itens -->
        <div style="display: flex; font-size: 10px; font-weight: bold; border-bottom: 1px solid #ccc; padding: 4px 0;">
          <div style="flex: 1;">ITEM</div>
          <div style="width: 40px; text-align: center;">QTD</div>
          <div style="width: 70px; text-align: right;">UNIT</div>
          <div style="width: 70px; text-align: right;">TOTAL</div>
        </div>
        
        <!-- Itens -->
        ${(itens.length > 0 ? itens : ultimaVenda?.itens || []).map((item, idx) => `
          <div style="display: flex; font-size: 11px; padding: 3px 0; border-bottom: 1px dotted #eee;">
            <div style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${idx + 1}. ${item.descricao.substring(0, 18)}</div>
            <div style="width: 40px; text-align: center;">${item.quantidade}</div>
            <div style="width: 70px; text-align: right;">${formatarMoeda(item.precoUnitario)}</div>
            <div style="width: 70px; text-align: right;">${formatarMoeda(item.total)}</div>
          </div>
        `).join('')}
        
        <div style="border-top: 1px dashed #000; margin: 8px 0;"></div>
        
        <!-- Totais -->
        <div style="font-size: 11px;">
          <div style="display: flex; justify-content: space-between;">
            <span>Subtotal:</span>
            <span>${formatarMoeda(subtotal || ultimaVenda?.subtotal || 0)}</span>
          </div>
          ${desconto > 0 ? `
            <div style="display: flex; justify-content: space-between; color: #dc2626;">
              <span>Desconto:</span>
              <span>-${formatarMoeda(desconto)}</span>
            </div>
          ` : ''}
          <div style="display: flex; justify-content: space-between; font-size: 14px; font-weight: bold; margin-top: 4px;">
            <span>TOTAL:</span>
            <span>${formatarMoeda(total || ultimaVenda?.total || 0)}</span>
          </div>
        </div>
        
        <div style="border-top: 1px dashed #000; margin: 8px 0;"></div>
        
        <!-- Pagamento -->
        <div style="font-size: 11px;">
          <div><strong>Forma:</strong> ${formaPagamento.replace('_', ' ').toUpperCase() || ultimaVenda?.formaPagamento?.replace('_', ' ').toUpperCase() || '-'}</div>
          ${(valorPago || ultimaVenda?.valorPago) ? `
            <div><strong>Pago:</strong> ${formatarMoeda(parseFloat(valorPago) || ultimaVenda?.valorPago || 0)}</div>
          ` : ''}
          ${(troco || ultimaVenda?.troco) ? `
            <div style="color: #ea580c; font-weight: bold;"><strong>Troco:</strong> ${formatarMoeda(troco || ultimaVenda?.troco || 0)}</div>
          ` : ''}
        </div>
        
        <div style="border-top: 1px dashed #000; margin: 8px 0;"></div>
        
        <div style="text-align: center; font-size: 10px; color: #666;">
          <div>Obrigado pela preferência!</div>
          <div>TecOS - Sistema de Gestão</div>
        </div>
      </div>
    `
  }

  // ====== IMPRESSÃO DO CUPOM ======
  const imprimirCupom = () => {
    if (!ultimaVenda) return

    const dadosLoja = loja || { nome: 'TecOS PDV', endereco: '', telefone: '' }
    const largura = tipoImpressao === 'a4' ? '210mm' : tamanhoTermica
    const tamanhoFonte = tipoImpressao === 'a4' ? '14px' : (tamanhoTermica === '58mm' ? '10px' : '12px')
    const padding = tipoImpressao === 'a4' ? '20px' : (tamanhoTermica === '58mm' ? '5px' : '10px')

    const conteudo = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Cupom Não Fiscal</title>
        <style>
          @page { 
            size: ${tipoImpressao === 'a4' ? 'A4 portrait' : tamanhoTermica}; 
            margin: 0;
          }
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { 
            font-family: 'Courier New', monospace; 
            font-size: ${tamanhoFonte}; 
            width: ${largura}; 
            margin: 0 auto; 
            padding: ${padding};
            background: white;
          }
          .header { text-align: center; margin-bottom: 10px; }
          .logo { font-size: 18px; font-weight: bold; }
          .subtitle { font-size: 10px; color: #666; margin-top: 2px; }
          .line { border-top: 1px dashed #000; margin: 8px 0; }
          .info { font-size: 11px; margin: 2px 0; }
          .item-header { display: flex; font-size: 10px; font-weight: bold; border-bottom: 1px solid #000; padding: 4px 0; }
          .item-header .col1 { flex: 1; }
          .item-header .col2 { width: 35px; text-align: center; }
          .item-header .col3 { width: 60px; text-align: right; }
          .item-header .col4 { width: 60px; text-align: right; }
          .item-row { display: flex; font-size: 11px; padding: 2px 0; border-bottom: 1px dotted #ccc; }
          .item-row .col1 { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
          .item-row .col2 { width: 35px; text-align: center; }
          .item-row .col3 { width: 60px; text-align: right; }
          .item-row .col4 { width: 60px; text-align: right; }
          .total-row { display: flex; justify-content: space-between; margin: 2px 0; }
          .total-final { font-size: 16px; font-weight: bold; margin-top: 6px; }
          .footer { text-align: center; font-size: 10px; color: #666; margin-top: 10px; }
          @media print {
            body { margin: 0; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">${dadosLoja.nome}</div>
          <div class="subtitle">CUPOM NÃO FISCAL</div>
        </div>
        
        <div class="line"></div>
        
        <div class="info"><strong>Venda:</strong> #${ultimaVenda.numeroVenda}</div>
        <div class="info"><strong>Data:</strong> ${new Date().toLocaleString('pt-BR')}</div>
        ${ultimaVenda.clienteNome ? `<div class="info"><strong>Cliente:</strong> ${ultimaVenda.clienteNome}</div>` : ''}
        ${dadosLoja.endereco ? `<div class="info"><strong>Endereço:</strong> ${dadosLoja.endereco}</div>` : ''}
        ${dadosLoja.telefone ? `<div class="info"><strong>Telefone:</strong> ${dadosLoja.telefone}</div>` : ''}
        
        <div class="line"></div>
        
        <div class="item-header">
          <div class="col1">ITEM</div>
          <div class="col2">QTD</div>
          <div class="col3">UNIT</div>
          <div class="col4">TOTAL</div>
        </div>
        
        ${ultimaVenda.itens.map((item, idx) => `
          <div class="item-row">
            <div class="col1">${idx + 1}. ${item.descricao.substring(0, 20)}</div>
            <div class="col2">${item.quantidade}</div>
            <div class="col3">${formatarMoeda(item.precoUnitario)}</div>
            <div class="col4">${formatarMoeda(item.total)}</div>
          </div>
        `).join('')}
        
        <div class="line"></div>
        
        <div class="total-row">
          <span>Subtotal:</span>
          <span>${formatarMoeda(ultimaVenda.subtotal || ultimaVenda.total)}</span>
        </div>
        ${ultimaVenda.desconto && ultimaVenda.desconto > 0 ? `
          <div class="total-row" style="color: #dc2626;">
            <span>Desconto:</span>
            <span>-${formatarMoeda(ultimaVenda.desconto)}</span>
          </div>
        ` : ''}
        <div class="total-row total-final">
          <span>TOTAL:</span>
          <span>${formatarMoeda(ultimaVenda.total)}</span>
        </div>
        
        <div class="line"></div>
        
        <div class="info"><strong>Forma de Pagamento:</strong> ${ultimaVenda.formaPagamento.replace('_', ' ').toUpperCase()}</div>
        ${ultimaVenda.valorPago ? `<div class="info"><strong>Valor Pago:</strong> ${formatarMoeda(ultimaVenda.valorPago)}</div>` : ''}
        ${ultimaVenda.troco && ultimaVenda.troco > 0 ? `<div class="info" style="color: #ea580c; font-weight: bold;"><strong>Troco:</strong> ${formatarMoeda(ultimaVenda.troco)}</div>` : ''}
        
        <div class="line"></div>
        
        <div class="footer">
          <div>Obrigado pela preferência!</div>
          <div>TecOS - Sistema de Gestão</div>
        </div>
      </body>
      </html>
    `

    const janela = window.open('', '_blank')
    if (janela) {
      janela.document.write(conteudo)
      janela.document.close()
      setTimeout(() => janela.print(), 300)
    }
    
    setShowImpressao(false)
    setShowCupom(false)
  }

  const fecharCaixa = async () => {
    if (!saldoFinalInput) {
      toast.error('Informe o saldo final')
      return
    }

    setFechandoCaixa(true)
    try {
      const res = await fetch('/api/painel/pdv/caixa/fechar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caixaId: caixa?.id,
          saldoFinal: parseFloat(saldoFinalInput),
          observacao: observacaoFechamento
        })
      })
      const data = await res.json()
      
      if (data.success) {
        setResumoFechamento(data.resumo)
        toast.success('Caixa fechado com sucesso!')
        setCaixa(null)
        setShowFecharCaixa(false)
        setSaldoFinalInput('')
        setObservacaoFechamento('')
      } else {
        toast.error(data.error || 'Erro ao fechar caixa')
      }
    } catch {
      toast.error('Erro ao fechar caixa')
    } finally {
      setFechandoCaixa(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  if (!caixa) {
    return (
      <div className="max-w-md mx-auto mt-12">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl flex items-center justify-center gap-2">
              <Wallet className="w-8 h-8 text-emerald-600" />
              Abrir Caixa
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-center text-slate-500 mb-4">
              Não há caixa aberto. Abra o caixa para iniciar as vendas.
            </p>
            <div className="space-y-2">
              <Label>Saldo Inicial</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="0,00"
                defaultValue="0"
                id="saldoInicial"
              />
            </div>
            <Button
              className="w-full h-12 text-lg"
              onClick={() => {
                const input = document.getElementById('saldoInicial') as HTMLInputElement
                abrirCaixa(parseFloat(input.value) || 0)
              }}
            >
              <Check className="w-5 h-5 mr-2" />
              Abrir Caixa
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="h-[calc(100vh-120px)] flex flex-col lg:flex-row gap-4">
      {/* Coluna Esquerda - Produtos/Carrinho */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header com ações */}
        <div className="flex flex-wrap gap-2 mb-4">
          <Button
            variant="outline"
            onClick={() => setShowBarcodeInput(true)}
            className="gap-2"
          >
            <Barcode className="w-4 h-4" />
            Código de Barras
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setShowBuscaProdutos(true)
              setTimeout(() => searchInputRef.current?.focus(), 100)
            }}
            className="gap-2"
          >
            <Search className="w-4 h-4" />
            Buscar (F2)
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowVendaAvulsa(true)}
            className="gap-2"
          >
            <Plus className="w-4 h-4" />
            Avulso (F3)
          </Button>
          {itens.length > 0 && (
            <Button
              variant="destructive"
              onClick={limparCarrinho}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Limpar
            </Button>
          )}
          <div className="flex-1" />
          <Button
            variant="outline"
            onClick={() => setShowFecharCaixa(true)}
            className="gap-2 text-red-600 hover:text-red-700"
          >
            <Wallet className="w-4 h-4" />
            Fechar Caixa
          </Button>
        </div>

        {/* Lista de itens do carrinho */}
        <Card className="flex-1 min-h-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              Carrinho
              {itens.length > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {itens.reduce((acc, item) => acc + item.quantidade, 0)} itens
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {itens.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-slate-400">
                <Package className="w-16 h-16 mb-4" />
                <p className="text-lg">Carrinho vazio</p>
                <p className="text-sm">Escaneie ou busque produtos</p>
              </div>
            ) : (
              <ScrollArea className="h-[calc(100vh-400px)]">
                <div className="divide-y">
                  {itens.map((item) => (
                    <div key={item.id} className="p-4 flex items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium truncate">{item.descricao}</p>
                          {item.tipo === 'avulso' && (
                            <Badge variant="outline" className="text-xs">Avulso</Badge>
                          )}
                        </div>
                        <p className="text-sm text-slate-500">
                          {formatarMoeda(item.precoUnitario)} cada
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => atualizarQuantidade(item.id, item.quantidade - 1)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="w-8 text-center font-medium">{item.quantidade}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => atualizarQuantidade(item.id, item.quantidade + 1)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="text-right min-w-[80px]">
                        <p className="font-bold">{formatarMoeda(item.total)}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removerItem(item.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Coluna Direita - Totais e Pagamento */}
      <div className="w-full lg:w-96 flex flex-col gap-4">
        {/* Total */}
        <Card className="bg-emerald-600 text-white">
          <CardContent className="p-6">
            <p className="text-emerald-100 text-sm">Total</p>
            <p className="text-4xl font-bold">{formatarMoeda(total)}</p>
            {desconto > 0 && (
              <p className="text-emerald-200 text-sm mt-1">
                Desconto: -{formatarMoeda(desconto)}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Desconto */}
        <Card>
          <CardContent className="p-4">
            <Label className="text-sm text-slate-500">Desconto (R$)</Label>
            <Input
              type="number"
              step="0.01"
              value={desconto || ''}
              onChange={(e) => setDesconto(parseFloat(e.target.value) || 0)}
              placeholder="0,00"
              className="mt-1"
            />
          </CardContent>
        </Card>

        {/* Botões de ação */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            className="h-16"
            onClick={() => router.push('/painel/pdv/produtos')}
          >
            <Package className="w-5 h-5 mr-2" />
            Produtos
          </Button>
          <Button
            variant="outline"
            className="h-16"
            onClick={() => router.push('/painel/pdv/vendas')}
          >
            <Receipt className="w-5 h-5 mr-2" />
            Vendas
          </Button>
        </div>

        {/* Botão Finalizar */}
        <Button
          className="h-20 text-xl font-bold"
          disabled={itens.length === 0}
          onClick={() => setShowPagamento(true)}
        >
          <CreditCard className="w-6 h-6 mr-2" />
          Finalizar Venda (F4)
        </Button>
      </div>

      {/* Modal de Código de Barras */}
      <Dialog open={showBarcodeInput} onOpenChange={setShowBarcodeInput}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Ler Código de Barras</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              ref={barcodeInputRef}
              placeholder="Escaneie ou digite o código..."
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  const value = (e.target as HTMLInputElement).value
                  if (value.trim()) {
                    buscarProdutoPorCodigo(value.trim())
                    setShowBarcodeInput(false)
                  }
                }
              }}
              autoFocus
            />
            <p className="text-sm text-slate-500 text-center">
              Posicione o leitor e escaneie o código
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Sheet de Busca de Produtos */}
      <Sheet open={showBuscaProdutos} onOpenChange={setShowBuscaProdutos}>
        <SheetContent>
          <SheetHeader>
            <SheetTitle>Buscar Produtos</SheetTitle>
          </SheetHeader>
          <div className="space-y-4 mt-4">
            <Input
              ref={searchInputRef}
              placeholder="Buscar por nome ou código..."
              value={busca}
              onChange={(e) => {
                setBusca(e.target.value)
                buscarProdutos(e.target.value)
              }}
            />
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-2">
                {produtosBusca.map((produto) => (
                  <Card 
                    key={produto.id} 
                    className="cursor-pointer hover:bg-emerald-50 transition-colors"
                    onClick={() => {
                      adicionarItem(produto)
                      setShowBuscaProdutos(false)
                      setBusca('')
                      setProdutosBusca([])
                    }}
                  >
                    <CardContent className="p-3">
                      <p className="font-medium">{produto.nome}</p>
                      <div className="flex justify-between text-sm text-slate-500">
                        <span>Estoque: {produto.estoque}</span>
                        <span className="font-bold text-emerald-600">{formatarMoeda(produto.precoVenda)}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {busca && produtosBusca.length === 0 && (
                  <p className="text-center text-slate-400 py-8">
                    Nenhum produto encontrado
                  </p>
                )}
              </div>
            </ScrollArea>
          </div>
        </SheetContent>
      </Sheet>

      {/* Modal de Venda Avulsa */}
      <Dialog open={showVendaAvulsa} onOpenChange={setShowVendaAvulsa}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Venda Avulsa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Descrição</Label>
              <Input
                value={avulsaDescricao}
                onChange={(e) => setAvulsaDescricao(e.target.value)}
                placeholder="Ex: Serviço de instalação"
              />
            </div>
            <div className="space-y-2">
              <Label>Valor (R$)</Label>
              <Input
                type="number"
                step="0.01"
                value={avulsaValor}
                onChange={(e) => setAvulsaValor(e.target.value)}
                placeholder="0,00"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowVendaAvulsa(false)}>
              Cancelar
            </Button>
            <Button onClick={adicionarItemAvulso}>
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Pagamento */}
      <Dialog open={showPagamento} onOpenChange={setShowPagamento}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Finalizar Venda</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Resumo */}
            <div className="bg-slate-50 rounded-lg p-4">
              <div className="flex justify-between text-sm">
                <span>Itens:</span>
                <span>{itens.reduce((acc, item) => acc + item.quantidade, 0)}</span>
              </div>
              <div className="flex justify-between font-bold text-xl mt-2">
                <span>Total:</span>
                <span className="text-emerald-600">{formatarMoeda(total)}</span>
              </div>
            </div>

            {/* Cliente */}
            <div className="space-y-2">
              <Label>Nome do Cliente (opcional)</Label>
              <Input
                value={clienteNome}
                onChange={(e) => setClienteNome(e.target.value)}
                placeholder="Nome do cliente"
              />
            </div>

            {/* Forma de pagamento */}
            <div className="space-y-2">
              <Label>Forma de Pagamento</Label>
              <div className="grid grid-cols-2 gap-2">
                {formasPagamento.map((forma) => (
                  <Button
                    key={forma.value}
                    variant={formaPagamento === forma.value ? 'default' : 'outline'}
                    className={`h-16 ${formaPagamento === forma.value ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
                    onClick={() => setFormaPagamento(forma.value)}
                  >
                    <forma.icon className="w-5 h-5 mr-2" />
                    {forma.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Valor pago (dinheiro) */}
            {formaPagamento === 'dinheiro' && (
              <div className="space-y-2">
                <Label>Valor Pago (R$)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={valorPago}
                  onChange={(e) => setValorPago(e.target.value)}
                  placeholder="0,00"
                />
                {valorPago && parseFloat(valorPago) >= total && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                    <span className="text-amber-700">Troco: </span>
                    <span className="font-bold text-amber-700">{formatarMoeda(troco)}</span>
                  </div>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPagamento(false)}>
              Cancelar
            </Button>
            <Button onClick={finalizarVenda} className="bg-emerald-600 hover:bg-emerald-700">
              <Check className="w-4 h-4 mr-2" />
              Confirmar Venda
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Cupom com seleção de impressão */}
      <Dialog open={showCupom} onOpenChange={setShowCupom}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Receipt className="w-5 h-5" />
              Venda #{ultimaVenda?.numeroVenda} - Concluída!
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Seleção de tipo de impressão */}
            <div className="bg-slate-50 rounded-lg p-4 space-y-4">
              <div>
                <Label className="text-sm font-medium">Tipo de Impressão</Label>
                <div className="flex gap-2 mt-2">
                  <Button
                    variant={tipoImpressao === 'termica' ? 'default' : 'outline'}
                    className={`flex-1 h-12 ${tipoImpressao === 'termica' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
                    onClick={() => setTipoImpressao('termica')}
                  >
                    <Printer className="w-4 h-4 mr-2" />
                    Térmica
                  </Button>
                  <Button
                    variant={tipoImpressao === 'a4' ? 'default' : 'outline'}
                    className={`flex-1 h-12 ${tipoImpressao === 'a4' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
                    onClick={() => setTipoImpressao('a4')}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    A4
                  </Button>
                </div>
              </div>

              {/* Tamanho - só para térmica */}
              {tipoImpressao === 'termica' && (
                <div>
                  <Label className="text-sm font-medium">Tamanho do Papel</Label>
                  <Select value={tamanhoTermica} onValueChange={(v) => setTamanhoTermica(v as '58mm' | '80mm')}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="80mm">80mm (padrão)</SelectItem>
                      <SelectItem value="58mm">58mm (mini)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            {/* Pré-visualização do recibo */}
            <div className="border rounded-lg p-2 bg-slate-100">
              <p className="text-xs text-slate-500 mb-2 text-center">Pré-visualização do Recibo</p>
              <div 
                className="bg-white rounded shadow-sm overflow-auto max-h-[300px]"
                dangerouslySetInnerHTML={{ __html: gerarPreviewRecibo() }}
              />
            </div>
          </div>

          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button 
              variant="outline" 
              onClick={() => setShowCupom(false)}
              className="w-full sm:w-auto"
            >
              Fechar
            </Button>
            <Button 
              onClick={imprimirCupom}
              className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700"
            >
              <Printer className="w-4 h-4 mr-2" />
              Imprimir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Fechar Caixa */}
      <Dialog open={showFecharCaixa} onOpenChange={setShowFecharCaixa}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Fechar Caixa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-lg p-4 space-y-2">
              <p className="text-sm text-slate-500">Saldo Inicial</p>
              <p className="text-xl font-bold">{formatarMoeda(caixa?.saldoInicial || 0)}</p>
            </div>
            <div className="space-y-2">
              <Label>Saldo Final em Caixa (R$)</Label>
              <Input
                type="number"
                step="0.01"
                value={saldoFinalInput}
                onChange={(e) => setSaldoFinalInput(e.target.value)}
                placeholder="0,00"
              />
            </div>
            <div className="space-y-2">
              <Label>Observação (opcional)</Label>
              <Input
                value={observacaoFechamento}
                onChange={(e) => setObservacaoFechamento(e.target.value)}
                placeholder="Observações..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFecharCaixa(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={fecharCaixa} 
              disabled={fechandoCaixa}
              className="bg-red-600 hover:bg-red-700"
            >
              {fechandoCaixa ? 'Fechando...' : 'Fechar Caixa'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Caixa Existente - Fechar e Abrir Novo */}
      <Dialog open={showCaixaExistente} onOpenChange={setShowCaixaExistente}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-600">
              <Wallet className="w-5 h-5" />
              Já existe um caixa aberto
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <p className="text-sm text-amber-800">
                Já existe um caixa aberto para esta loja. Deseja fechar o caixa atual e abrir um novo?
              </p>
            </div>
            <div className="bg-slate-50 rounded-lg p-4 space-y-2">
              <p className="text-sm text-slate-500">Caixa Atual</p>
              <p className="font-medium">Saldo Inicial: {formatarMoeda(caixa?.saldoInicial || 0)}</p>
              <p className="text-xs text-slate-400">Aberto em: {caixa?.id ? 'ID: ' + caixa.id.substring(0, 8) + '...' : '-'}</p>
            </div>
            <div className="bg-emerald-50 rounded-lg p-4 space-y-2">
              <p className="text-sm text-emerald-700">Novo Caixa</p>
              <p className="font-medium">Saldo Inicial: {formatarMoeda(novoSaldoInicial)}</p>
            </div>
          </div>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button 
              variant="outline" 
              onClick={() => setShowCaixaExistente(false)}
              className="w-full sm:w-auto"
            >
              Manter Caixa Atual
            </Button>
            <Button 
              onClick={fecharEAbrirNovoCaixa} 
              disabled={fechandoCaixa}
              className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700"
            >
              {fechandoCaixa ? 'Processando...' : 'Fechar Atual e Abrir Novo'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

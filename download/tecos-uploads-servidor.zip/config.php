<?php
// config.php - Configurações do servidor de imagens TecOS

// Chave de API para autenticação - DEVE SER IGUAL AO .env DO VERCEL
define('API_KEY', 'a8f7d9e2b4c1m6n3p5q0r9s2t8u1v4w7');

// URL base do servidor
define('BASE_URL', 'https://sorteiomax.com.br/tecos-uploads');

// Tipos de arquivos permitidos
define('ALLOWED_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// Tamanho máximo em bytes (10MB)
define('MAX_SIZE', 10 * 1024 * 1024);

// Pasta raiz dos uploads
define('UPLOAD_DIR', __DIR__ . '/lojas/');

// Habilitar logs (true ou false)
define('ENABLE_LOGS', true);

// Função para log
function logUpload($mensagem) {
    if (ENABLE_LOGS) {
        $logFile = __DIR__ . '/uploads.log';
        $data = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$data] $mensagem\n", FILE_APPEND);
    }
}
?>
